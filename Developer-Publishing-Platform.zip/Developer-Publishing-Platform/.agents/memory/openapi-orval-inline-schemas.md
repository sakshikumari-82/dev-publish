---
name: OpenAPI Orval inline schemas
description: Avoid duplicate generated Zod exports when extending the OpenAPI contract.
---

When adding request bodies to this workspace's OpenAPI contract, prefer named component schemas referenced with `$ref` over repeated inline operation schemas.

**Why:** Orval can emit the same inline body as both an operation validator and a generated type, creating duplicate exports that fail the library typecheck.

**How to apply:** After every contract change, run API codegen and `pnpm run typecheck` before using the generated client or validators.