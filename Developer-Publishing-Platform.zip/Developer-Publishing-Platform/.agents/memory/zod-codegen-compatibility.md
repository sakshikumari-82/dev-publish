---
name: Zod codegen compatibility
description: OpenAPI-generated validators in this workspace currently require Zod 4 APIs.
---

The Orval Zod output uses top-level Zod 4 helpers such as email, uuid, url, and int. Keep the workspace Zod catalog on a Zod 4 release or codegen output will typecheck inconsistently and crash the API at runtime.

**Why:** The initial scaffold resolved Zod 3 while generated code emitted Zod 4 calls, causing both library typecheck failures and a server startup crash.

**How to apply:** After changing the OpenAPI contract, run codegen and verify both `pnpm run typecheck` and the API workflow startup.