# Dev Publish

Dev Publish is an original, database-backed developer blogging and publishing platform. It supports real accounts, drafts, publishing, discovery, author profiles, community interactions, moderation, and provider-neutral monetization foundations—not disconnected mock pages or hard-coded application data.

## Architecture

```text
React + React Router + generated React Query hooks
                    │
                    ▼
          Express REST API under /api
          ├─ Zod request/response validation
          ├─ JWT + PostgreSQL-backed sessions
          ├─ authentication and role middleware
          └─ domain route modules
                    │
                    ▼
       PostgreSQL through Drizzle ORM
       users, sessions, posts, taxonomy,
       comments, likes, bookmarks, follows,
       notifications, reports, media, creator plans,
       subscriptions, transactions, earnings, payouts,
       advertising placements/events
```

The OpenAPI document at `lib/api-spec/openapi.yaml` is the source of truth for client/server contracts. Run codegen after changing it:

```bash
pnpm --filter @workspace/api-spec run codegen
```

## Workspace map

- `artifacts/dev-publish` — React web app and routing.
- `artifacts/api-server` — Express API, auth middleware, route modules, error handling.
- `lib/api-spec` — OpenAPI contract and Orval configuration.
- `lib/api-client-react` — generated React Query client.
- `lib/api-zod` — generated Zod validators/types.
- `lib/db` — Drizzle connection and PostgreSQL schema.

## Run locally in Replit

The managed workflows are the supported way to run the product:

```bash
pnpm --filter @workspace/api-server run dev
pnpm --filter @workspace/dev-publish run dev
```

Required environment:

- `DATABASE_URL` — provided by the Replit PostgreSQL database.
- `SESSION_SECRET` or `JWT_SECRET` — used to sign JWTs. `JWT_SECRET` is preferred for deployments.

Schema changes are applied to the development database with:

```bash
pnpm --filter @workspace/db run push
```

Run the full static validation with:

```bash
pnpm run typecheck
```

## Product scope

The contract and schema cover signup/login/logout, profiles, drafts and publishing, categories/tags, search, comments/replies, likes, bookmarks, follow relationships, notifications, dashboard summaries, admin overview, and advertising placements/events.

Advertising is deliberately modeled as a separate module. Placements can later store a legitimate provider and provider placement ID. Events are deduplicated by provider event ID and only record observed impressions/clicks; the system does not generate traffic, clicks, or revenue.

## Security boundaries

- Passwords are stored as salted scrypt hashes, never plaintext.
- JWTs are signed with an environment secret and tied to a PostgreSQL session record.
- Protected routes require a valid bearer token and an unexpired session.
- Role checks are available for moderator/admin-only routes.
- Zod validates request boundaries before domain logic runs.
- Server logs redact authorization and cookie headers.

## Verification

The managed workflows have been verified through the shared proxy. Static typecheck and production-style frontend/API builds pass. A database-backed smoke flow has covered signup, authenticated `/auth/me`, draft creation/read, taxonomy persistence, publishing, public reads, likes, bookmarks, comments, filtered search, unauthorized editing, and owner deletion.