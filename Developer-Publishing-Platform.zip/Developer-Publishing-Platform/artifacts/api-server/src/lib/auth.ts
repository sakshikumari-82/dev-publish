import {
  createHmac,
  randomBytes,
  scrypt as scryptCallback,
  timingSafeEqual,
} from "node:crypto";
import { promisify } from "node:util";

const scrypt = promisify(scryptCallback);
const TOKEN_TTL_SECONDS = 60 * 60 * 24 * 7;

function secret() {
  const value = process.env.JWT_SECRET ?? process.env.SESSION_SECRET;
  if (!value) throw new Error("JWT_SECRET or SESSION_SECRET must be configured");
  return value;
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return `scrypt$${salt}$${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string) {
  const [, salt, expectedHex] = stored.split("$");
  if (!salt || !expectedHex) return false;
  const expected = Buffer.from(expectedHex, "hex");
  const actual = (await scrypt(password, salt, expected.length)) as Buffer;
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

function base64Url(value: string | Buffer) {
  return Buffer.from(value).toString("base64url");
}

export function signToken(userId: string, sessionId: string) {
  const header = base64Url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const payload = base64Url(
    JSON.stringify({
      sub: userId,
      sid: sessionId,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + TOKEN_TTL_SECONDS,
    }),
  );
  const input = `${header}.${payload}`;
  const signature = base64Url(createHmac("sha256", secret()).update(input).digest());
  return `${input}.${signature}`;
}

export function verifyToken(token: string) {
  const [header, payload, signature] = token.split(".");
  if (!header || !payload || !signature) return null;
  const input = `${header}.${payload}`;
  const expected = createHmac("sha256", secret()).update(input).digest("base64url");
  if (expected.length !== signature.length || !timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) {
    return null;
  }
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as {
      sub?: string;
      sid?: string;
      exp?: number;
    };
    if (!data.sub || !data.sid || !data.exp || data.exp < Math.floor(Date.now() / 1000)) return null;
    return { userId: data.sub, sessionId: data.sid, expiresAt: new Date(data.exp * 1000) };
  } catch {
    return null;
  }
}

export { TOKEN_TTL_SECONDS };