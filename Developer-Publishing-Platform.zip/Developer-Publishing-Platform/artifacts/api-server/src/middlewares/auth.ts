import type { NextFunction, Request, Response } from "express";
import { eq } from "drizzle-orm";
import { db, sessions, users } from "@workspace/db";
import { verifyToken } from "../lib/auth";

declare global {
  namespace Express {
    interface Request {
      user?: typeof users.$inferSelect;
    }
  }
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authorization = req.header("authorization");
  const token = authorization?.startsWith("Bearer ") ? authorization.slice(7) : undefined;
  const claims = token ? verifyToken(token) : null;
  if (!claims) return res.status(401).json({ error: "Authentication required" });

  const [session] = await db
    .select({ session: sessions, user: users })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(eq(sessions.id, claims.sessionId))
    .limit(1);
  if (!session || session.session.expiresAt < new Date() || session.session.userId !== claims.userId) {
    return res.status(401).json({ error: "Session expired" });
  }
  req.user = session.user;
  return next();
}

export async function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const authorization = req.header("authorization");
  const token = authorization?.startsWith("Bearer ") ? authorization.slice(7) : undefined;
  const claims = token ? verifyToken(token) : null;
  if (claims) {
    const [session] = await db.select({ session: sessions, user: users })
      .from(sessions).innerJoin(users, eq(users.id, sessions.userId))
      .where(eq(sessions.id, claims.sessionId)).limit(1);
    if (session && session.session.expiresAt >= new Date() && session.session.userId === claims.userId) req.user = session.user;
  }
  return next();
}

export function requireRole(...roles: Array<"member" | "moderator" | "admin">) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) return res.status(403).json({ error: "Forbidden" });
    return next();
  };
}