import { Router, type IRouter } from "express";
import { eq, or } from "drizzle-orm";
import { db, sessions, users } from "@workspace/db";
import {
  LoginBody,
  SignupBody,
  GetCurrentUserResponse,
  LoginResponse,
  SignupResponse,
} from "@workspace/api-zod";
import { hashPassword, signToken, TOKEN_TTL_SECONDS, verifyPassword } from "../lib/auth";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

function publicUser(user: typeof users.$inferSelect) {
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    bio: user.bio,
    avatarUrl: user.avatarUrl,
    role: user.role,
  };
}

async function createSession(user: typeof users.$inferSelect) {
  const [session] = await db.insert(sessions).values({
    userId: user.id,
    tokenHash: "jwt-session",
    expiresAt: new Date(Date.now() + TOKEN_TTL_SECONDS * 1000),
  }).returning();
  if (!session) throw new Error("Unable to create session");
  return { token: signToken(user.id, session.id), user: publicUser(user) };
}

router.post("/auth/signup", async (req, res, next) => {
  try {
    const input = SignupBody.parse(req.body);
    const email = input.email.toLowerCase();
    const [existing] = await db.select({ id: users.id }).from(users).where(
      or(eq(users.email, email), eq(users.username, input.username)),
    ).limit(1);
    if (existing) return res.status(409).json({ error: "Email or username already exists" });
    const [user] = await db.insert(users).values({
      email,
      username: input.username,
      displayName: input.displayName,
      passwordHash: await hashPassword(input.password),
    }).returning();
    if (!user) return res.status(500).json({ error: "Unable to create account" });
    return res.status(201).json(SignupResponse.parse(await createSession(user)));
  } catch (error) {
    return next(error);
  }
});

router.post("/auth/login", async (req, res, next) => {
  try {
    const input = LoginBody.parse(req.body);
    const [user] = await db.select().from(users).where(eq(users.email, input.email.toLowerCase())).limit(1);
    if (!user || !(await verifyPassword(input.password, user.passwordHash))) {
      return res.status(401).json({ error: "Invalid email or password" });
    }
    return res.json(LoginResponse.parse(await createSession(user)));
  } catch (error) {
    return next(error);
  }
});

router.post("/auth/logout", requireAuth, async (req, res, next) => {
  try {
    const token = req.header("authorization")?.slice(7);
    const claims = token ? (await import("../lib/auth")).verifyToken(token) : null;
    if (claims) await db.delete(sessions).where(eq(sessions.id, claims.sessionId));
    return res.status(204).send();
  } catch (error) {
    return next(error);
  }
});

router.get("/auth/me", requireAuth, (req, res) => res.json(GetCurrentUserResponse.parse(publicUser(req.user!))));

export default router;