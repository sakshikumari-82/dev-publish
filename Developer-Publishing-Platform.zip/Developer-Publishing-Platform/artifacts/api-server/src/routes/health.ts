import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";
import { sql } from "drizzle-orm";
import { db } from "@workspace/db";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  void db.execute(sql`select 1`)
    .then(() => res.json(HealthCheckResponse.parse({ status: "ok" })))
    .catch(() => res.status(503).json({ status: "unavailable" }));
});

export default router;
