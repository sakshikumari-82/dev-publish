import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import postsRouter from "./posts";
import socialRouter from "./social";
import usersRouter from "./users";
import platformRouter from "./platform";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(postsRouter);
router.use(socialRouter);
router.use(usersRouter);
router.use(platformRouter);

export default router;
