import { Router, type IRouter } from "express";
import { and, count, desc, eq, sql } from "drizzle-orm";
import { db, adEvents, adPlacements, creatorPlans, earnings, follows, likes, notifications, posts, reports, users } from "@workspace/db";
import { requireAuth, requireRole } from "../middlewares/auth";
import { ListNotificationsResponse, ListAdPlacementsResponse } from "@workspace/api-zod";
import { z } from "zod";
import { toPost } from "./posts";

const router: IRouter = Router();

router.get("/notifications", requireAuth, async (req, res, next) => {
  try {
    const rows = await db.select().from(notifications).where(eq(notifications.userId, req.user!.id)).orderBy(desc(notifications.createdAt)).limit(50);
    return res.json(ListNotificationsResponse.parse(rows.map((item) => ({ ...item, createdAt: item.createdAt.toISOString() }))));
  } catch (error) { return next(error); }
});

router.post("/notifications/:id/read", requireAuth, async (req, res, next) => {
  try {
    await db.update(notifications).set({ read: true }).where(and(eq(notifications.id, String(req.params.id)), eq(notifications.userId, req.user!.id)));
    return res.status(204).send();
  } catch (error) { return next(error); }
});

router.get("/dashboard/summary", requireAuth, async (req, res, next) => {
  try {
    const [publishedRow] = await db.select({ value: count() }).from(posts).where(and(eq(posts.authorId, req.user!.id), eq(posts.status, "published")));
    const [draftsRow] = await db.select({ value: count() }).from(posts).where(and(eq(posts.authorId, req.user!.id), eq(posts.status, "draft")));
    const [followersRow] = await db.select({ value: count() }).from(follows).where(eq(follows.followingId, req.user!.id));
    const [likesRow] = await db.select({ value: count() }).from(likes).innerJoin(posts, eq(likes.postId, posts.id)).where(eq(posts.authorId, req.user!.id));
    const recentRows = await db.select({ post: posts, author: users }).from(posts).innerJoin(users, eq(users.id, posts.authorId)).where(eq(posts.authorId, req.user!.id)).orderBy(desc(posts.updatedAt)).limit(5);
    const recentPosts = await Promise.all(recentRows.map((row) => toPost(row, req.user!.id)));
    return res.json({ posts: Number(publishedRow?.value ?? 0), drafts: Number(draftsRow?.value ?? 0), followers: Number(followersRow?.value ?? 0), totalLikes: Number(likesRow?.value ?? 0), recentPosts });
  } catch (error) { return next(error); }
});

router.get("/dashboard/posts", requireAuth, async (req, res, next) => {
  try {
    const rows = await db.select({ post: posts, author: users }).from(posts).innerJoin(users, eq(users.id, posts.authorId)).where(eq(posts.authorId, req.user!.id)).orderBy(desc(posts.updatedAt)).limit(100);
    return res.json(await Promise.all(rows.map((row) => toPost(row, req.user!.id))));
  } catch (error) { return next(error); }
});

router.get("/admin/overview", requireAuth, requireRole("admin", "moderator"), async (_req, res, next) => {
  try {
    const [usersRow] = await db.select({ value: count() }).from(users);
    const [postsRow] = await db.select({ value: count() }).from(posts);
    const [publishedRow] = await db.select({ value: count() }).from(posts).where(eq(posts.status, "published"));
    const [reportsRow] = await db.select({ value: count() }).from(reports).where(eq(reports.status, "open"));
    return res.json({ users: Number(usersRow?.value ?? 0), posts: Number(postsRow?.value ?? 0), publishedPosts: Number(publishedRow?.value ?? 0), pendingReports: Number(reportsRow?.value ?? 0) });
  } catch (error) { return next(error); }
});

router.get("/advertising/placements", async (_req, res, next) => {
  try {
    const rows = await db.select().from(adPlacements).where(eq(adPlacements.status, "active"));
    return res.json(ListAdPlacementsResponse.parse(rows));
  } catch (error) { return next(error); }
});

router.get("/admin/advertising/placements", requireAuth, requireRole("admin"), async (_req, res, next) => {
  try { return res.json(await db.select().from(adPlacements).orderBy(desc(adPlacements.createdAt))); } catch (error) { return next(error); }
});

const placementInput = z.object({
  name: z.string().min(1).max(120),
  provider: z.string().max(120).nullable().optional(),
  providerPlacementId: z.string().max(200).nullable().optional(),
  status: z.enum(["active", "paused"]).default("paused"),
  slot: z.enum(["feed", "article", "profile"]),
});

router.post("/admin/advertising/placements", requireAuth, requireRole("admin"), async (req, res, next) => {
  try { const input = placementInput.parse(req.body); const [row] = await db.insert(adPlacements).values(input).returning(); return res.status(201).json(row); } catch (error) { return next(error); }
});

router.patch("/admin/advertising/placements/:id", requireAuth, requireRole("admin"), async (req, res, next) => {
  try { const input = placementInput.partial().parse(req.body); const [row] = await db.update(adPlacements).set(input).where(eq(adPlacements.id, String(req.params.id))).returning(); return row ? res.json(row) : res.status(404).json({ error: "Placement not found" }); } catch (error) { return next(error); }
});

router.get("/admin/advertising/events", requireAuth, requireRole("admin"), async (_req, res, next) => {
  try { return res.json(await db.select().from(adEvents).orderBy(desc(adEvents.createdAt)).limit(200)); } catch (error) { return next(error); }
});

router.get("/admin/reports", requireAuth, requireRole("admin", "moderator"), async (_req, res, next) => {
  try { return res.json(await db.select().from(reports).orderBy(desc(reports.createdAt)).limit(200)); } catch (error) { return next(error); }
});

router.patch("/admin/reports/:id", requireAuth, requireRole("admin", "moderator"), async (req, res, next) => {
  try {
    const input = z.object({ status: z.enum(["open", "resolved", "dismissed"]) }).parse(req.body);
    const [report] = await db.update(reports).set({ status: input.status, resolvedAt: input.status === "open" ? null : new Date() }).where(eq(reports.id, String(req.params.id))).returning();
    return report ? res.json(report) : res.status(404).json({ error: "Report not found" });
  } catch (error) { return next(error); }
});

router.get("/monetization/summary", requireAuth, async (req, res, next) => {
  try {
    const [row] = await db.select({ gross: sql<number>`coalesce(sum(${earnings.grossCents}), 0)`, commission: sql<number>`coalesce(sum(${earnings.commissionCents}), 0)`, net: sql<number>`coalesce(sum(${earnings.netCents}), 0)` }).from(earnings).where(eq(earnings.creatorId, req.user!.id));
    const plans = await db.select().from(creatorPlans).where(eq(creatorPlans.creatorId, req.user!.id)).orderBy(desc(creatorPlans.createdAt));
    return res.json({ grossCents: Number(row?.gross ?? 0), commissionCents: Number(row?.commission ?? 0), netCents: Number(row?.net ?? 0), plans });
  } catch (error) { return next(error); }
});

router.post("/monetization/plans", requireAuth, async (req, res, next) => {
  try {
    const input = z.object({ name: z.string().min(1).max(120), description: z.string().max(500).nullable().optional(), amountCents: z.number().int().min(0), providerPriceId: z.string().max(200).nullable().optional() }).parse(req.body);
    const [plan] = await db.insert(creatorPlans).values({ ...input, creatorId: req.user!.id }).returning();
    return res.status(201).json(plan);
  } catch (error) { return next(error); }
});

router.post("/advertising/events", async (req, res, next) => {
  try {
    const input = z.object({ placementId: z.string().uuid(), eventType: z.enum(["impression", "click"]), eventId: z.string().min(8).max(200), occurredAt: z.coerce.date().optional() }).parse(req.body);
    const [placement] = await db.select().from(adPlacements).where(eq(adPlacements.id, input.placementId)).limit(1);
    if (!placement || placement.status !== "active") return res.status(404).json({ error: "Active placement not found" });
    await db.insert(adEvents).values({ ...input, occurredAt: input.occurredAt ?? new Date() }).onConflictDoNothing();
    return res.status(202).send();
  } catch (error) { return next(error); }
});

export default router;