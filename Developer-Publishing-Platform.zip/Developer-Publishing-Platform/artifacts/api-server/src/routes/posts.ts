import { Router, type IRouter } from "express";
import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { db, bookmarks, categories, comments, likes, postTags, posts, tags, users } from "@workspace/db";
import {
  CreatePostBody,
  CreatePostResponse,
  DeletePostParams,
  GetPostParams,
  GetPostResponse,
  ListPostsQueryParams,
  ListPostsResponse,
  UpdatePostBody,
  UpdatePostParams,
  UpdatePostResponse,
} from "@workspace/api-zod";
import { optionalAuth, requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

const slugify = (value: string) =>
  `${value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "")}-${Date.now().toString(36)}`;

export async function toPost(row: {
  post: typeof posts.$inferSelect;
  author: typeof users.$inferSelect;
  likesCount?: number;
  commentsCount?: number;
}, viewerId?: string) {
  const [category] = row.post.categoryId
    ? await db.select({ name: categories.name }).from(categories).where(eq(categories.id, row.post.categoryId)).limit(1)
    : [];
  const tagRows = await db.select({ name: tags.name }).from(postTags).innerJoin(tags, eq(tags.id, postTags.tagId)).where(eq(postTags.postId, row.post.id));
  const [likesRow] = await db.select({ value: sql<number>`count(*)` }).from(likes).where(eq(likes.postId, row.post.id));
  const [commentsRow] = await db.select({ value: sql<number>`count(*)` }).from(comments).where(eq(comments.postId, row.post.id));
  const [viewerLike] = viewerId ? await db.select().from(likes).where(and(eq(likes.postId, row.post.id), eq(likes.userId, viewerId))).limit(1) : [];
  const [viewerBookmark] = viewerId ? await db.select().from(bookmarks).where(and(eq(bookmarks.postId, row.post.id), eq(bookmarks.userId, viewerId))).limit(1) : [];
  return {
    id: row.post.id,
    slug: row.post.slug,
    title: row.post.title,
    excerpt: row.post.excerpt,
    coverImageUrl: row.post.coverImageUrl,
    content: row.post.content,
    status: row.post.status,
    category: category?.name ?? null,
    author: {
      id: row.author.id,
      username: row.author.username,
      displayName: row.author.displayName,
      bio: row.author.bio,
      avatarUrl: row.author.avatarUrl,
      role: row.author.role,
    },
    tags: tagRows.map((tag) => tag.name),
    likesCount: Number(row.likesCount ?? likesRow?.value ?? 0),
    commentsCount: Number(row.commentsCount ?? commentsRow?.value ?? 0),
    views: row.post.views,
    isLiked: Boolean(viewerLike),
    isBookmarked: Boolean(viewerBookmark),
    publishedAt: row.post.publishedAt?.toISOString() ?? null,
  };
}

async function findPost(slug: string) {
  const [row] = await db.select({ post: posts, author: users }).from(posts)
    .innerJoin(users, eq(users.id, posts.authorId)).where(eq(posts.slug, slug)).limit(1);
  return row;
}

const taxonomySlug = (value: string) => value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

async function saveTaxonomy(postId: string, categoryName?: string | null, tagNames?: string[]) {
  let categoryId: string | null = null;
  if (categoryName?.trim()) {
    const slug = taxonomySlug(categoryName);
    const [existing] = await db.select().from(categories).where(or(eq(categories.slug, slug), eq(categories.name, categoryName.trim()))).limit(1);
    const category = existing ?? (await db.insert(categories).values({ name: categoryName.trim(), slug }).returning())[0];
    categoryId = category?.id ?? null;
  }
  await db.update(posts).set({ categoryId }).where(eq(posts.id, postId));
  await db.delete(postTags).where(eq(postTags.postId, postId));
  for (const name of [...new Set((tagNames ?? []).map((tag) => tag.trim()).filter(Boolean))]) {
    const slug = taxonomySlug(name);
    const [existing] = await db.select().from(tags).where(or(eq(tags.slug, slug), eq(tags.name, name))).limit(1);
    const tag = existing ?? (await db.insert(tags).values({ name, slug }).returning())[0];
    if (tag) await db.insert(postTags).values({ postId, tagId: tag.id }).onConflictDoNothing();
  }
}

router.get("/posts", optionalAuth, async (req, res, next) => {
  try {
    const query = ListPostsQueryParams.parse(req.query);
    const page = query.page ?? 1;
    const limit = query.limit ?? 20;
    const filter = [eq(posts.status, "published" as const)];
    if (query.search) filter.push(or(ilike(posts.title, `%${query.search}%`), ilike(posts.content, `%${query.search}%`))!);
    if (query.author) filter.push(eq(users.username, query.author));
    if (query.category) filter.push(sql`exists (select 1 from categories c where c.id = ${posts.categoryId} and (c.slug = ${query.category} or c.name ilike ${`%${query.category}%`}))`);
    if (query.tag) filter.push(sql`exists (select 1 from post_tags pt inner join tags t on t.id = pt.tag_id where pt.post_id = ${posts.id} and (t.slug = ${query.tag} or t.name ilike ${`%${query.tag}%`}))`);
    const [totalRow] = await db.select({ value: sql<number>`count(*)` }).from(posts).innerJoin(users, eq(users.id, posts.authorId)).where(and(...filter));
    const rows = await db.select({ post: posts, author: users })
      .from(posts).innerJoin(users, eq(users.id, posts.authorId))
      .where(and(...filter)).orderBy(desc(posts.publishedAt)).limit(limit).offset((page - 1) * limit);
    const data = { items: await Promise.all(rows.map((row) => toPost(row, req.user?.id))), page, limit, total: Number(totalRow?.value ?? 0) };
    return res.json(ListPostsResponse.parse(data));
  } catch (error) {
    return next(error);
  }
});

router.post("/posts", requireAuth, async (req, res, next) => {
  try {
    const input = CreatePostBody.parse(req.body);
    const [post] = await db.insert(posts).values({
      authorId: req.user!.id,
      slug: slugify(input.title),
      title: input.title,
      excerpt: input.excerpt ?? null,
      coverImageUrl: input.coverImageUrl ?? null,
      content: input.content,
      status: input.status,
      publishedAt: input.status === "published" ? new Date() : null,
    }).returning();
    if (!post) return res.status(500).json({ error: "Unable to create post" });
    await saveTaxonomy(post.id, input.category, input.tags);
    const [fresh] = await db.select().from(posts).where(eq(posts.id, post.id)).limit(1);
    return res.status(201).json(CreatePostResponse.parse(await toPost({ post: fresh ?? post, author: req.user! }, req.user!.id)));
  } catch (error) {
    return next(error);
  }
});

router.get("/posts/:slug", optionalAuth, async (req, res, next) => {
  try {
    const params = GetPostParams.parse(req.params);
    const row = await findPost(params.slug);
    if (!row || (row.post.status !== "published" && row.post.authorId !== req.user?.id)) {
      return res.status(404).json({ error: "Post not found" });
    }
    if (row.post.status === "published" && row.post.authorId !== req.user?.id) {
      await db.update(posts).set({ views: sql`${posts.views} + 1` }).where(eq(posts.id, row.post.id));
      row.post.views += 1;
    }
    return res.json(GetPostResponse.parse(await toPost(row, req.user?.id)));
  } catch (error) {
    return next(error);
  }
});

router.patch("/posts/:slug", requireAuth, async (req, res, next) => {
  try {
    const params = UpdatePostParams.parse(req.params);
    const input = UpdatePostBody.parse(req.body);
    const existing = await findPost(params.slug);
    if (!existing || existing.post.authorId !== req.user!.id) return res.status(404).json({ error: "Post not found" });
    const [updated] = await db.update(posts).set({
      ...(input.title !== undefined ? { title: input.title, slug: slugify(input.title) } : {}),
      ...(input.excerpt !== undefined ? { excerpt: input.excerpt } : {}),
      ...(input.coverImageUrl !== undefined ? { coverImageUrl: input.coverImageUrl } : {}),
      ...(input.content !== undefined ? { content: input.content } : {}),
      ...(input.status !== undefined ? { status: input.status, publishedAt: input.status === "published" ? new Date() : null } : {}),
      updatedAt: new Date(),
    }).where(eq(posts.id, existing.post.id)).returning();
    if (!updated) return res.status(500).json({ error: "Unable to update post" });
    await saveTaxonomy(updated.id, input.category, input.tags);
    const [fresh] = await db.select().from(posts).where(eq(posts.id, updated.id)).limit(1);
    return res.json(UpdatePostResponse.parse(await toPost({ post: fresh ?? updated, author: req.user! }, req.user!.id)));
  } catch (error) {
    return next(error);
  }
});

router.delete("/posts/:slug", requireAuth, async (req, res, next) => {
  try {
    const params = DeletePostParams.parse(req.params);
    const existing = await findPost(params.slug);
    if (!existing || existing.post.authorId !== req.user!.id) return res.status(404).json({ error: "Post not found" });
    await db.delete(posts).where(eq(posts.id, existing.post.id));
    return res.status(204).send();
  } catch (error) {
    return next(error);
  }
});

export default router;