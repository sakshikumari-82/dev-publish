import { Router, type IRouter } from "express";
import { and, desc, eq, isNull, sql } from "drizzle-orm";
import { db, bookmarks, comments, follows, likes, notifications, posts, reports, users } from "@workspace/db";
import { CreateCommentBody, ListCommentsResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";
import { z } from "zod";

const router: IRouter = Router();

async function getPost(slug: string) {
  const [row] = await db.select({ post: posts, author: users }).from(posts)
    .innerJoin(users, eq(users.id, posts.authorId)).where(eq(posts.slug, slug)).limit(1);
  return row;
}

async function notify(userId: string, type: "comment" | "reply" | "like" | "follow", message: string) {
  await db.insert(notifications).values({ userId, type, message });
}

router.post("/posts/:slug/like", requireAuth, async (req, res, next) => {
  try {
    const row = await getPost(String(req.params.slug));
    if (!row) return res.status(404).json({ error: "Post not found" });
    const inserted = await db.insert(likes).values({ userId: req.user!.id, postId: row.post.id }).onConflictDoNothing().returning();
    if (inserted.length && row.post.authorId !== req.user!.id) await notify(row.post.authorId, "like", `${req.user!.displayName} liked your post`);
    return res.status(204).send();
  } catch (error) { return next(error); }
});

router.delete("/posts/:slug/like", requireAuth, async (req, res, next) => {
  try {
    const row = await getPost(String(req.params.slug));
    if (!row) return res.status(404).json({ error: "Post not found" });
    await db.delete(likes).where(and(eq(likes.userId, req.user!.id), eq(likes.postId, row.post.id)));
    return res.status(204).send();
  } catch (error) { return next(error); }
});

router.post("/posts/:slug/bookmark", requireAuth, async (req, res, next) => {
  try {
    const row = await getPost(String(req.params.slug));
    if (!row) return res.status(404).json({ error: "Post not found" });
    await db.insert(bookmarks).values({ userId: req.user!.id, postId: row.post.id }).onConflictDoNothing();
    return res.status(204).send();
  } catch (error) { return next(error); }
});

router.delete("/posts/:slug/bookmark", requireAuth, async (req, res, next) => {
  try {
    const row = await getPost(String(req.params.slug));
    if (!row) return res.status(404).json({ error: "Post not found" });
    await db.delete(bookmarks).where(and(eq(bookmarks.userId, req.user!.id), eq(bookmarks.postId, row.post.id)));
    return res.status(204).send();
  } catch (error) { return next(error); }
});

router.get("/posts/:slug/comments", async (req, res, next) => {
  try {
    const row = await getPost(String(req.params.slug));
    if (!row) return res.status(404).json({ error: "Post not found" });
    const rows = await db.select({ comment: comments, author: users }).from(comments)
      .innerJoin(users, eq(users.id, comments.authorId)).where(eq(comments.postId, row.post.id)).orderBy(desc(comments.createdAt));
    const byId = new Map<string, any>();
    rows.forEach(({ comment, author }) => byId.set(comment.id, {
      id: comment.id,
      body: comment.body,
      author: { id: author.id, username: author.username, displayName: author.displayName, bio: author.bio, avatarUrl: author.avatarUrl, role: author.role },
      createdAt: comment.createdAt.toISOString(),
      replies: [],
    }));
    const roots: any[] = [];
    rows.forEach(({ comment }) => {
      const item = byId.get(comment.id);
      if (comment.parentId && byId.get(comment.parentId)) byId.get(comment.parentId).replies.push(item);
      else roots.push(item);
    });
    return res.json(ListCommentsResponse.parse(roots));
  } catch (error) { return next(error); }
});

router.post("/posts/:slug/comments", requireAuth, async (req, res, next) => {
  try {
    const input = CreateCommentBody.parse(req.body);
    const row = await getPost(String(req.params.slug));
    if (!row) return res.status(404).json({ error: "Post not found" });
    if (input.parentId) {
      const [parent] = await db.select({ id: comments.id, postId: comments.postId }).from(comments).where(eq(comments.id, input.parentId)).limit(1);
      if (!parent || parent.postId !== row.post.id) return res.status(400).json({ error: "Reply target does not belong to this post" });
    }
    const [comment] = await db.insert(comments).values({
      postId: row.post.id, authorId: req.user!.id, parentId: input.parentId ?? null, body: input.body,
    }).returning();
    if (!comment) return res.status(500).json({ error: "Unable to create comment" });
    const recipient = input.parentId ? (await db.select({ userId: comments.authorId }).from(comments).where(eq(comments.id, input.parentId)).limit(1))[0]?.userId : row.post.authorId;
    if (recipient && recipient !== req.user!.id) await notify(recipient, input.parentId ? "reply" : "comment", `${req.user!.displayName} commented on your post`);
    return res.status(201).json({
      id: comment.id, body: comment.body,
      author: { id: req.user!.id, username: req.user!.username, displayName: req.user!.displayName, bio: req.user!.bio, avatarUrl: req.user!.avatarUrl, role: req.user!.role },
      createdAt: comment.createdAt.toISOString(), replies: [],
    });
  } catch (error) { return next(error); }
});

router.delete("/comments/:id", requireAuth, async (req, res, next) => {
  try {
    const [comment] = await db.select().from(comments).where(eq(comments.id, String(req.params.id))).limit(1);
    if (!comment || comment.authorId !== req.user!.id) return res.status(404).json({ error: "Comment not found" });
    await db.delete(comments).where(eq(comments.id, comment.id));
    return res.status(204).send();
  } catch (error) { return next(error); }
});

router.post("/reports", requireAuth, async (req, res, next) => {
  try {
    const input = z.object({ postId: z.string().uuid().optional(), commentId: z.string().uuid().optional(), reason: z.string().min(3).max(500) }).refine((value) => value.postId || value.commentId, "A post or comment is required").parse(req.body);
    const [report] = await db.insert(reports).values({ ...input, reporterId: req.user!.id }).returning();
    return res.status(201).json(report);
  } catch (error) { return next(error); }
});

export default router;