import { Router, type IRouter } from "express";
import { and, count, desc, eq, sql } from "drizzle-orm";
import { db, bookmarks, follows, posts, users } from "@workspace/db";
import { GetUserProfileResponse } from "@workspace/api-zod";
import { z } from "zod";
import { optionalAuth, requireAuth } from "../middlewares/auth";
import { toPost } from "./posts";

const router: IRouter = Router();

function publicUser(user: typeof users.$inferSelect) {
  return { id: user.id, username: user.username, displayName: user.displayName, bio: user.bio, avatarUrl: user.avatarUrl, role: user.role };
}

router.patch("/users/me", requireAuth, async (req, res, next) => {
  try {
    const input = z.object({
      displayName: z.string().min(1).max(80).optional(),
      bio: z.string().max(500).nullable().optional(),
      avatarUrl: z.string().url().nullable().optional(),
    }).parse(req.body);
    const [updated] = await db.update(users).set({ ...input, updatedAt: new Date() }).where(eq(users.id, req.user!.id)).returning();
    return res.json(publicUser(updated ?? req.user!));
  } catch (error) { return next(error); }
});

router.get("/users/:username", optionalAuth, async (req, res, next) => {
  try {
    const [user] = await db.select().from(users).where(eq(users.username, String(req.params.username))).limit(1);
    if (!user) return res.status(404).json({ error: "User not found" });
    const [followersRow] = await db.select({ value: count() }).from(follows).where(eq(follows.followingId, user.id));
    const [followingRow] = await db.select({ value: count() }).from(follows).where(eq(follows.followerId, user.id));
    const [postsRow] = await db.select({ value: count() }).from(posts).where(and(eq(posts.authorId, user.id), eq(posts.status, "published")));
    const isFollowing = req.user ? Boolean((await db.select().from(follows).where(and(eq(follows.followerId, req.user.id), eq(follows.followingId, user.id))).limit(1))[0]) : false;
    return res.json(GetUserProfileResponse.parse({ ...publicUser(user), followersCount: Number(followersRow?.value ?? 0), followingCount: Number(followingRow?.value ?? 0), postsCount: Number(postsRow?.value ?? 0), isFollowing }));
  } catch (error) { return next(error); }
});

router.post("/users/:username/follow", requireAuth, async (req, res, next) => {
  try {
    const [target] = await db.select().from(users).where(eq(users.username, String(req.params.username))).limit(1);
    if (!target) return res.status(404).json({ error: "User not found" });
    if (target.id === req.user!.id) return res.status(400).json({ error: "You cannot follow yourself" });
    await db.insert(follows).values({ followerId: req.user!.id, followingId: target.id }).onConflictDoNothing();
    if (target.id !== req.user!.id) await db.insert((await import("@workspace/db")).notifications).values({ userId: target.id, type: "follow", message: `${req.user!.displayName} followed you` });
    return res.status(204).send();
  } catch (error) { return next(error); }
});

router.delete("/users/:username/follow", requireAuth, async (req, res, next) => {
  try {
    const [target] = await db.select().from(users).where(eq(users.username, String(req.params.username))).limit(1);
    if (!target) return res.status(404).json({ error: "User not found" });
    await db.delete(follows).where(and(eq(follows.followerId, req.user!.id), eq(follows.followingId, target.id)));
    return res.status(204).send();
  } catch (error) { return next(error); }
});

router.get("/users/:username/posts", optionalAuth, async (req, res, next) => {
  try {
    const [author] = await db.select().from(users).where(eq(users.username, String(req.params.username))).limit(1);
    if (!author) return res.status(404).json({ error: "User not found" });
    const rows = await db.select({ post: posts, author: users }).from(posts).innerJoin(users, eq(users.id, posts.authorId))
      .where(and(eq(posts.authorId, author.id), eq(posts.status, "published"))).orderBy(desc(posts.publishedAt)).limit(50);
    return res.json(await Promise.all(rows.map((row) => toPost(row, req.user?.id))));
  } catch (error) { return next(error); }
});

router.get("/bookmarks", requireAuth, async (req, res, next) => {
  try {
    const rows = await db.select({ post: posts, author: users }).from(bookmarks)
      .innerJoin(posts, eq(posts.id, bookmarks.postId)).innerJoin(users, eq(users.id, posts.authorId))
      .where(eq(bookmarks.userId, req.user!.id)).orderBy(desc(bookmarks.createdAt)).limit(100);
    return res.json(await Promise.all(rows.map((row) => toPost(row, req.user!.id))));
  } catch (error) { return next(error); }
});

export default router;