import { FormEvent, useEffect, useState } from "react";
import { BrowserRouter, Link, Navigate, Route, Routes, useLocation, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import { ErrorBoundary } from "@/components/error-boundary";
import { api, type AdPlacement, type Comment, type Dashboard, type Notification, type Post, type Profile, type User } from "@/lib/api";
import "./index.css";

type AuthState = { user: User | null; refresh: () => Promise<void> };

function useAsync<T>(loader: () => Promise<T>, deps: unknown[] = []) {
  const [state, setState] = useState<{ data?: T; loading: boolean; error?: string }>({ loading: true });
  useEffect(() => {
    let active = true;
    setState({ loading: true });
    loader().then((data) => active && setState({ data, loading: false })).catch((error: unknown) => active && setState({ loading: false, error: error instanceof Error ? error.message : "Unable to load data" }));
    return () => { active = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return state;
}

function useAuthState(): AuthState {
  const [user, setUser] = useState<User | null>(null);
  const refresh = async () => {
    if (!localStorage.getItem("dev-publish-token")) { setUser(null); return; }
    try { setUser(await api.me()); } catch { localStorage.removeItem("dev-publish-token"); setUser(null); }
  };
  useEffect(() => { void refresh(); }, []);
  return { user, refresh };
}

function Shell({ auth, children }: { auth: AuthState; children: React.ReactNode }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [menu, setMenu] = useState(false);
  async function logout() { await api.logout().catch(() => undefined); localStorage.removeItem("dev-publish-token"); await auth.refresh(); navigate("/"); }
  return <div className="app-shell">
    <header className="topbar">
      <Link to="/" className="brand"><span className="brand-mark">DP</span><span>Dev Publish</span></Link>
      <nav className="main-nav">
        <Link className={location.pathname === "/" ? "active" : ""} to="/">Discover</Link>
        {auth.user && <Link className={location.pathname.startsWith("/dashboard") ? "active" : ""} to="/dashboard">Workspace</Link>}
      </nav>
      <div className="top-actions">
        {auth.user ? <>
          <Link className="write-button" to="/write">Write</Link>
          <button className="avatar-button" onClick={() => setMenu(!menu)}>{auth.user.displayName.slice(0, 1).toUpperCase()}</button>
          {menu && <div className="account-menu"><Link to={`/profile/${auth.user.username}`}>Profile</Link><Link to="/bookmarks">Bookmarks</Link><Link to="/notifications">Notifications</Link><Link to="/settings">Settings</Link><Link to="/monetization">Monetization</Link>{auth.user.role === "admin" && <Link to="/admin">Admin</Link>}<button onClick={logout}>Sign out</button></div>}
        </> : <Link className="write-button" to="/login">Sign in</Link>}
      </div>
    </header>
    {children}
    <footer className="footer"><span>Dev Publish</span><span>Write with intent. Share what you learn.</span></footer>
  </div>;
}

function Loading() { return <div className="state-card"><span className="spinner" /> Loading from PostgreSQL…</div>; }
function ErrorState({ message }: { message?: string }) { return <div className="state-card error-state"><strong>We couldn’t load this yet.</strong><span>{message ?? "Please try again."}</span></div>; }
function Empty({ title, text }: { title: string; text: string }) { return <div className="state-card"><strong>{title}</strong><span>{text}</span></div>; }

function PostCard({ post }: { post: Post }) {
  return <article className="post-card">
    <div className="post-card-meta"><Link to={`/profile/${post.author.username}`} className="author-chip"><span className="mini-avatar">{post.author.displayName.slice(0, 1)}</span>{post.author.displayName}</Link><span>{post.publishedAt ? new Date(post.publishedAt).toLocaleDateString() : "Draft"}</span></div>
    <Link to={`/post/${post.slug}`}><h2>{post.title}</h2><p>{post.excerpt || post.content.slice(0, 150)}</p></Link>
    <div className="post-card-footer"><div className="tag-row">{post.category && <span className="tag category-tag">{post.category}</span>}{post.tags?.slice(0, 3).map((tag) => <span className="tag" key={tag}>#{tag}</span>)}</div><span>{post.likesCount} likes · {post.commentsCount} comments</span></div>
  </article>;
}

function HomePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const search = searchParams.get("search") ?? "";
  const category = searchParams.get("category") ?? "";
  const tag = searchParams.get("tag") ?? "";
  const [term, setTerm] = useState(search);
  const [categoryTerm, setCategoryTerm] = useState(category);
  const [tagTerm, setTagTerm] = useState(tag);
  const result = useAsync(() => api.posts({ search, category, tag, page: 1, limit: 20 }), [search, category, tag]);
  function submit(event: FormEvent) { event.preventDefault(); setSearchParams({ ...(term ? { search: term } : {}), ...(categoryTerm ? { category: categoryTerm } : {}), ...(tagTerm ? { tag: tagTerm } : {}) }); }
  return <main className="page-container">
    <section className="hero-row"><div><p className="eyebrow">THE DEVELOPER COMMONS</p><h1>Ideas worth shipping.</h1><p className="hero-copy">A focused home for engineers who explain the work behind the code.</p></div><div className="hero-note">Build in public.<br /><strong>Learn together.</strong></div></section>
    <form className="search-bar" onSubmit={submit}><span>⌕</span><input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Search articles, topics, authors…" /><input value={categoryTerm} onChange={(e) => setCategoryTerm(e.target.value)} placeholder="Category" /><input value={tagTerm} onChange={(e) => setTagTerm(e.target.value)} placeholder="Tag" /><button>Search</button></form>
    <div className="section-heading"><div><p className="eyebrow">LATEST FROM THE COMMUNITY</p><h2>{search ? `Results for “${search}”` : "Fresh thinking"}</h2></div><span className="result-count">{result.data?.total ?? 0} articles</span></div>
    {result.loading ? <Loading /> : result.error ? <ErrorState message={result.error} /> : result.data?.items.length ? <div className="post-grid">{result.data.items.map((post) => <PostCard key={post.id} post={post} />)}</div> : <Empty title="Nothing published yet" text="Be the first author to share something useful." />}
  </main>;
}

function AuthPage({ auth }: { auth: AuthState }) {
  const navigate = useNavigate();
  const [signup, setSignup] = useState(false);
  const [values, setValues] = useState({ email: "", password: "", username: "", displayName: "" });
  const [error, setError] = useState("");
  async function submit(event: FormEvent) {
    event.preventDefault(); setError("");
    try {
      const session = signup ? await api.signup(values) : await api.login({ email: values.email, password: values.password });
      localStorage.setItem("dev-publish-token", session.token); await auth.refresh(); navigate("/dashboard");
    } catch (e) { setError(e instanceof Error ? e.message : "Authentication failed"); }
  }
  const set = (key: keyof typeof values) => (e: React.ChangeEvent<HTMLInputElement>) => setValues((current) => ({ ...current, [key]: e.target.value }));
  return <main className="auth-page"><div className="auth-card"><p className="eyebrow">DEV PUBLISH</p><h1>{signup ? "Start writing in public." : "Welcome back."}</h1><p className="lede">{signup ? "Create a real author account and publish your first idea." : "Sign in to your workspace and keep building your body of work."}</p><form onSubmit={submit}>{signup && <><label>Username<input value={values.username} onChange={set("username")} minLength={3} required /></label><label>Display name<input value={values.displayName} onChange={set("displayName")} required /></label></>}<label>Email<input type="email" autoComplete="email" value={values.email} onChange={set("email")} required /></label><label>Password<input type="password" autoComplete={signup ? "new-password" : "current-password"} value={values.password} onChange={set("password")} minLength={signup ? 12 : 1} required /></label>{error && <p className="error-message">{error}</p>}<button className="primary-button">{signup ? "Create account" : "Sign in"}</button></form><button className="text-button switch-auth" onClick={() => setSignup(!signup)}>{signup ? "Already have an account? Sign in" : "New here? Create an account"}</button></div></main>;
}

function DashboardPage({ auth }: { auth: AuthState }) {
  const summary = useAsync(() => api.dashboard(), []);
  const posts = useAsync(() => api.dashboardPosts(), []);
  const navigate = useNavigate();
  if (!auth.user) return <Navigate to="/login" replace />;
  return <main className="page-container"><div className="dashboard-heading"><div><p className="eyebrow">AUTHOR WORKSPACE</p><h1>Your publishing desk.</h1><p className="hero-copy">A clear view of what you’re making and what’s already out in the world.</p></div><button className="primary-button compact" onClick={() => navigate("/write")}>+ New post</button></div>{summary.loading ? <Loading /> : summary.error ? <ErrorState message={summary.error} /> : <div className="metric-grid"><div><span>Published</span><strong>{summary.data?.posts}</strong></div><div><span>Drafts</span><strong>{summary.data?.drafts}</strong></div><div><span>Followers</span><strong>{summary.data?.followers}</strong></div><div><span>Total likes</span><strong>{summary.data?.totalLikes}</strong></div></div>}<div className="section-heading"><div><p className="eyebrow">YOUR WORK</p><h2>All posts</h2></div></div>{posts.loading ? <Loading /> : posts.error ? <ErrorState message={posts.error} /> : posts.data?.length ? <div className="dashboard-list">{posts.data.map((post) => <div className="dashboard-row" key={post.id}><div><span className={`status-pill ${post.status}`}>{post.status}</span><h3>{post.title}</h3><p>Last edited {new Date(post.updatedAt).toLocaleDateString()}</p></div><div className="row-actions"><Link to={`/write/${post.slug}`}>Edit</Link>{post.status === "published" && <Link to={`/post/${post.slug}`}>Read</Link>}</div></div>)}</div> : <Empty title="Your desk is empty" text="Start a draft and turn what you know into something useful." />}</main>;
}

function EditorPage({ auth }: { auth: AuthState }) {
  const { slug } = useParams();
  const navigate = useNavigate();
  const existing = useAsync(() => slug ? api.post(slug) : Promise.resolve(undefined), [slug]);
  const [form, setForm] = useState({ title: "", excerpt: "", content: "", coverImageUrl: "", category: "", tags: "" });
  const [status, setStatus] = useState<"draft" | "published">("draft");
  const [message, setMessage] = useState("");
  useEffect(() => { if (existing.data) setForm({ title: existing.data.title, excerpt: existing.data.excerpt ?? "", content: existing.data.content, coverImageUrl: existing.data.coverImageUrl ?? "", category: existing.data.category ?? "", tags: existing.data.tags?.join(", ") ?? "" }); if (existing.data?.status) setStatus(existing.data.status); }, [existing.data]);
  if (!auth.user) return <Navigate to="/login" replace />;
  if (existing.loading) return <main className="page-container"><Loading /></main>;
  if (existing.error && slug) return <main className="page-container"><ErrorState message={existing.error} /></main>;
  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setForm((current) => ({ ...current, [key]: e.target.value }));
  async function save(nextStatus: "draft" | "published") {
    setMessage("");
    try {
      const payload = { ...form, excerpt: form.excerpt || null, coverImageUrl: form.coverImageUrl || null, category: form.category || null, tags: form.tags.split(",").map((tag) => tag.trim()).filter(Boolean), status: nextStatus };
      const saved = slug ? await api.updatePost(slug, payload) : await api.createPost(payload);
      setStatus(nextStatus); setMessage(nextStatus === "published" ? "Published successfully." : "Draft saved.");
      if (!slug || saved.slug !== slug) navigate(`/write/${saved.slug}`, { replace: true });
    } catch (e) { setMessage(e instanceof Error ? e.message : "Unable to save"); }
  }
  async function remove() { if (!slug || !window.confirm("Delete this post permanently?")) return; await api.deletePost(slug); navigate("/dashboard"); }
  return <main className="editor-page"><div className="editor-toolbar"><Link to="/dashboard">← Workspace</Link><div><span className={`status-pill ${status}`}>{status}</span><button className="secondary-button" onClick={() => save("draft")}>Save draft</button><button className="primary-button compact" onClick={() => save("published")}>{status === "published" ? "Update publication" : "Publish"}</button></div></div><div className="editor-layout"><article className="editor-main"><input className="title-input" value={form.title} onChange={set("title")} placeholder="Give your post a title" /><textarea className="excerpt-input" value={form.excerpt} onChange={set("excerpt")} placeholder="A short description for readers…" rows={2} /><textarea className="content-input" value={form.content} onChange={set("content")} placeholder="Start writing. Markdown is supported by the reader." rows={22} /></article><aside className="editor-aside"><p className="eyebrow">POST SETTINGS</p><label>Cover image URL<input value={form.coverImageUrl} onChange={set("coverImageUrl")} placeholder="https://…" /></label><label>Category<input value={form.category} onChange={set("category")} placeholder="e.g. Engineering" /></label><label>Tags<input value={form.tags} onChange={set("tags")} placeholder="react, postgres, systems" /></label>{message && <p className={message.includes("successfully") || message.includes("saved") ? "success-message" : "error-message"}>{message}</p>}{slug && <button className="danger-button" onClick={remove}>Delete post</button>}</aside></div></main>;
}

function PostPage() {
  const { slug = "" } = useParams();
  const [post, setPost] = useState<Post | undefined>();
  const [error, setError] = useState("");
  const comments = useAsync(() => api.comments(slug), [slug]);
  const [comment, setComment] = useState("");
  const [liked, setLiked] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);
  useEffect(() => { api.post(slug).then(setPost).catch((e) => setError(e.message)); }, [slug]);
  if (error) return <main className="page-container"><ErrorState message={error} /></main>;
  if (!post) return <main className="page-container"><Loading /></main>;
  async function toggleLike() {
    const current = post;
    if (!current) return;
    const next = !liked;
    await api.like(slug, next);
    setLiked(next);
    setPost({ ...current, likesCount: Math.max(0, current.likesCount + (next ? 1 : -1)) });
  }
  async function toggleBookmark() { const next = !bookmarked; await api.bookmark(slug, next); setBookmarked(next); }
  async function submitComment(e: FormEvent) { e.preventDefault(); if (!comment.trim()) return; await api.comment(slug, { body: comment.trim() }); setComment(""); window.location.reload(); }
  return <main className="reader-page"><article className="reader"><div className="reader-kicker">{post.category || "ENGINEERING"} · {post.publishedAt && new Date(post.publishedAt).toLocaleDateString()}</div><h1>{post.title}</h1><p className="reader-excerpt">{post.excerpt}</p><div className="reader-author"><span className="large-avatar">{post.author.displayName.slice(0, 1)}</span><div><Link to={`/profile/${post.author.username}`}>{post.author.displayName}</Link><span>@{post.author.username}</span></div></div>{post.coverImageUrl && <img className="cover-image" src={post.coverImageUrl} alt="" />}<div className="reader-content">{post.content.split(/\n{2,}/).map((paragraph, i) => <p key={i}>{paragraph}</p>)}</div><div className="reader-actions"><button onClick={toggleLike} className={liked ? "action active" : "action"}>♥ {post.likesCount}</button><button onClick={toggleBookmark} className={bookmarked ? "action active" : "action"}>▣ {bookmarked ? "Saved" : "Save"}</button><span>{post.commentsCount} comments</span></div></article><section className="comments-section"><div className="section-heading"><div><p className="eyebrow">JOIN THE CONVERSATION</p><h2>Comments</h2></div></div><form className="comment-form" onSubmit={submitComment}><textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Share a thoughtful response…" rows={3} /><button className="primary-button compact">Comment</button></form>{comments.loading ? <Loading /> : comments.error ? <ErrorState message={comments.error} /> : comments.data?.length ? comments.data.map((item) => <CommentItem key={item.id} comment={item} />) : <Empty title="No comments yet" text="Start the conversation." />}</section></main>;
}

function CommentItem({ comment }: { comment: Comment }) { return <div className="comment"><div className="author-chip"><span className="mini-avatar">{comment.author.displayName.slice(0, 1)}</span><strong>{comment.author.displayName}</strong><span>{new Date(comment.createdAt).toLocaleDateString()}</span></div><p>{comment.body}</p>{comment.replies.map((reply) => <div className="reply" key={reply.id}><CommentItem comment={reply} /></div>)}</div>; }

function ProfilePage() {
  const { username = "" } = useParams();
  const profile = useAsync(() => api.profile(username), [username]);
  const posts = useAsync(() => api.profilePosts(username), [username]);
  const [following, setFollowing] = useState(false);
  useEffect(() => { if (profile.data) setFollowing(profile.data.isFollowing); }, [profile.data]);
  if (profile.loading) return <main className="page-container"><Loading /></main>;
  if (profile.error || !profile.data) return <main className="page-container"><ErrorState message={profile.error} /></main>;
  async function toggle() { const next = !following; await api.follow(username, next); setFollowing(next); }
  return <main className="page-container"><section className="profile-hero"><span className="profile-avatar">{profile.data.displayName.slice(0, 1)}</span><div><p className="eyebrow">AUTHOR PROFILE</p><h1>{profile.data.displayName}</h1><p className="profile-handle">@{profile.data.username}</p><p className="hero-copy">{profile.data.bio || "A developer sharing what they learn."}</p><div className="profile-stats"><span><strong>{profile.data.postsCount}</strong> posts</span><span><strong>{profile.data.followersCount}</strong> followers</span><span><strong>{profile.data.followingCount}</strong> following</span></div></div><button className={following ? "secondary-button" : "primary-button"} onClick={toggle}>{following ? "Following" : "Follow"}</button></section><div className="section-heading"><div><p className="eyebrow">PUBLISHED WORK</p><h2>From {profile.data.displayName}</h2></div></div>{posts.loading ? <Loading /> : posts.data?.length ? <div className="post-grid">{posts.data.map((post) => <PostCard key={post.id} post={post} />)}</div> : <Empty title="No published posts" text="This author hasn’t published anything yet." />}</main>;
}

function NotificationsPage() {
  const result = useAsync(() => api.notifications(), []);
  return <main className="page-container narrow-page"><p className="eyebrow">YOUR ACTIVITY</p><h1>Notifications</h1>{result.loading ? <Loading /> : result.error ? <ErrorState message={result.error} /> : result.data?.length ? <div className="notification-list">{result.data.map((item: Notification) => <div className={item.read ? "notification read" : "notification"} key={item.id}><span className="notification-dot" /><div><p>{item.message}</p><span>{new Date(item.createdAt).toLocaleString()}</span></div>{!item.read && <button onClick={() => api.readNotification(item.id)}>Mark read</button>}</div>)}</div> : <Empty title="You’re all caught up" text="New comments, likes, and follows will appear here." />}</main>;
}

function BookmarksPage({ auth }: { auth: AuthState }) {
  const result = useAsync(() => api.bookmarks(), []);
  if (!auth.user) return <Navigate to="/login" replace />;
  return <main className="page-container narrow-page"><p className="eyebrow">YOUR LIBRARY</p><h1>Bookmarks</h1>{result.loading ? <Loading /> : result.error ? <ErrorState message={result.error} /> : result.data?.length ? <div className="post-grid">{result.data.map((post) => <PostCard key={post.id} post={post} />)}</div> : <Empty title="No saved posts" text="Bookmark articles you want to return to." />}</main>;
}

function SettingsPage({ auth }: { auth: AuthState }) {
  const [form, setForm] = useState({ displayName: auth.user?.displayName ?? "", bio: auth.user?.bio ?? "", avatarUrl: auth.user?.avatarUrl ?? "" });
  const [message, setMessage] = useState("");
  if (!auth.user) return <Navigate to="/login" replace />;
  async function save(e: FormEvent) { e.preventDefault(); try { await api.updateProfile({ displayName: form.displayName, bio: form.bio || null, avatarUrl: form.avatarUrl || null }); await auth.refresh(); setMessage("Profile updated."); } catch (error) { setMessage(error instanceof Error ? error.message : "Unable to update profile"); } }
  return <main className="page-container narrow-page"><p className="eyebrow">ACCOUNT</p><h1>Settings</h1><form className="settings-form" onSubmit={save}><label>Display name<input required value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} /></label><label>Bio<textarea rows={5} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></label><label>Avatar image URL<input type="url" value={form.avatarUrl} onChange={(e) => setForm({ ...form, avatarUrl: e.target.value })} /></label><button className="primary-button compact">Save profile</button>{message && <p className={message.endsWith(".") ? "success-message" : "error-message"}>{message}</p>}</form></main>;
}

function MonetizationPage({ auth }: { auth: AuthState }) {
  const result = useAsync(() => api.monetization(), []);
  const [form, setForm] = useState({ name: "", description: "", amountCents: "0" });
  const [message, setMessage] = useState("");
  if (!auth.user) return <Navigate to="/login" replace />;
  async function create(e: FormEvent) { e.preventDefault(); try { await api.createPlan({ ...form, amountCents: Number(form.amountCents), description: form.description || null, providerPriceId: null }); setMessage("Plan foundation saved."); } catch (error) { setMessage(error instanceof Error ? error.message : "Unable to save plan"); } }
  return <main className="page-container"><p className="eyebrow">CREATOR ECONOMY</p><h1>Monetization foundation.</h1><p className="hero-copy">Prepare premium content and creator plans without pretending a payment has happened. Provider IDs and transaction records stay server-owned.</p>{result.loading ? <Loading /> : result.error ? <ErrorState message={result.error} /> : <div className="metric-grid"><div><span>Gross earnings</span><strong>${((result.data?.grossCents ?? 0) / 100).toFixed(2)}</strong></div><div><span>Commission</span><strong>${((result.data?.commissionCents ?? 0) / 100).toFixed(2)}</strong></div><div><span>Net earnings</span><strong>${((result.data?.netCents ?? 0) / 100).toFixed(2)}</strong></div><div><span>Plans</span><strong>{result.data?.plans.length ?? 0}</strong></div></div>}<section className="admin-grid"><form className="admin-form" onSubmit={create}><p className="eyebrow">NEW CREATOR PLAN</p><input placeholder="Plan name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /><textarea placeholder="What supporters receive" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /><input type="number" min="0" step="1" placeholder="Price in cents" value={form.amountCents} onChange={(e) => setForm({ ...form, amountCents: e.target.value })} /><button className="primary-button compact">Save plan foundation</button>{message && <p className="success-message">{message}</p>}</form><aside className="compliance-note"><p className="eyebrow">NO FAKE PAYMENTS</p><p>Payment, subscription, earnings, and payout tables are ready for a real provider integration. No charge, click, impression, traffic, or revenue is created here.</p></aside></section></main>;
}

function AdminPage({ auth }: { auth: AuthState }) {
  const stats = useAsync(() => api.admin(), []);
  const ads = useAsync(() => api.ads(), []);
  const reports = useAsync(() => api.reports(), []);
  const [form, setForm] = useState({ name: "", provider: "", providerPlacementId: "", slot: "article", status: "paused" });
  const [saved, setSaved] = useState(false);
  if (!auth.user || auth.user.role !== "admin") return <Navigate to="/" replace />;
  async function create(e: FormEvent) { e.preventDefault(); await api.createAd(form); setForm({ name: "", provider: "", providerPlacementId: "", slot: "article", status: "paused" }); setSaved(true); }
  return <main className="page-container"><p className="eyebrow">ADMINISTRATION</p><h1>Platform control room.</h1>{stats.loading ? <Loading /> : stats.error ? <ErrorState message={stats.error} /> : <div className="metric-grid"><div><span>Users</span><strong>{stats.data?.users}</strong></div><div><span>Total posts</span><strong>{stats.data?.posts}</strong></div><div><span>Published</span><strong>{stats.data?.publishedPosts}</strong></div><div><span>Open reports</span><strong>{stats.data?.pendingReports}</strong></div></div>}<div className="admin-grid"><section><div className="section-heading"><div><p className="eyebrow">AD PLACEMENTS</p><h2>Provider-neutral inventory</h2></div></div><form className="admin-form" onSubmit={create}><input placeholder="Placement name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /><input placeholder="Provider name (optional)" value={form.provider} onChange={(e) => setForm({ ...form, provider: e.target.value })} /><input placeholder="Provider placement ID" value={form.providerPlacementId} onChange={(e) => setForm({ ...form, providerPlacementId: e.target.value })} /><select value={form.slot} onChange={(e) => setForm({ ...form, slot: e.target.value })}><option value="feed">Feed</option><option value="article">Article</option><option value="profile">Profile</option></select><button className="primary-button compact">Add placement</button>{saved && <span className="success-message">Placement saved.</span>}</form>{ads.loading ? <Loading /> : ads.data?.map((ad: AdPlacement) => <div className="dashboard-row" key={ad.id}><div><h3>{ad.name}</h3><p>{ad.provider || "No provider connected"} · {ad.slot}</p></div><span className={`status-pill ${ad.status}`}>{ad.status}</span></div>)}<div className="section-heading"><div><p className="eyebrow">REPORTS / MODERATION</p><h2>Review queue</h2></div></div>{reports.loading ? <Loading /> : reports.data?.length ? reports.data.map((report) => <div className="dashboard-row" key={report.id}><div><h3>{report.reason}</h3><p>{report.postId ? `Post ${report.postId}` : `Comment ${report.commentId}`} · {new Date(report.createdAt).toLocaleDateString()}</p></div><select value={report.status} onChange={(e) => api.updateReport(report.id, e.target.value as "open" | "resolved" | "dismissed")}><option value="open">Open</option><option value="resolved">Resolved</option><option value="dismissed">Dismissed</option></select></div>) : <Empty title="No reports" text="The moderation queue is clear." />}</section><aside className="compliance-note"><p className="eyebrow">COMPLIANCE</p><h3>Auditable by design.</h3><p>Events are accepted only with provider event IDs and deduplicated in PostgreSQL. This system does not fabricate impressions, clicks, traffic, or revenue.</p></aside></div></main>;
}

function App() {
  const auth = useAuthState();
  useEffect(() => { setAuthTokenGetter(() => localStorage.getItem("dev-publish-token")); }, []);
  return <BrowserRouter><Shell auth={auth}><ErrorBoundary><Routes><Route path="/" element={<HomePage />} /><Route path="/login" element={<AuthPage auth={auth} />} /><Route path="/dashboard" element={<DashboardPage auth={auth} />} /><Route path="/write" element={<EditorPage auth={auth} />} /><Route path="/write/:slug" element={<EditorPage auth={auth} />} /><Route path="/post/:slug" element={<PostPage />} /><Route path="/profile/:username" element={<ProfilePage />} /><Route path="/bookmarks" element={<BookmarksPage auth={auth} />} /><Route path="/settings" element={<SettingsPage auth={auth} />} /><Route path="/monetization" element={<MonetizationPage auth={auth} />} /><Route path="/notifications" element={auth.user ? <NotificationsPage /> : <Navigate to="/login" replace />} /><Route path="/admin" element={<AdminPage auth={auth} />} /><Route path="*" element={<Navigate to="/" replace />} /></Routes></ErrorBoundary></Shell></BrowserRouter>;
}

export default App;