import {
  createComment as contractCreateComment,
  createPost as contractCreatePost,
  deletePost as contractDeletePost,
  followUser as contractFollowUser,
  getCurrentUser as contractGetCurrentUser,
  getPost as contractGetPost,
  getUserProfile as contractGetUserProfile,
  likePost as contractLikePost,
  listComments as contractListComments,
  listPosts as contractListPosts,
  login as contractLogin,
  logout as contractLogout,
  removeBookmark as contractRemoveBookmark,
  signup as contractSignup,
  unfollowUser as contractUnfollowUser,
  unlikePost as contractUnlikePost,
  updatePost as contractUpdatePost,
  bookmarkPost as contractBookmarkPost,
} from "@workspace/api-client-react";

export type User = { id: string; username: string; displayName: string; bio: string | null; avatarUrl: string | null; role: "member" | "moderator" | "admin" };
export type Post = { id: string; slug: string; title: string; excerpt: string | null; content: string; coverImageUrl?: string | null; status: "draft" | "published"; category: string | null; tags: string[]; author: User; likesCount: number; commentsCount: number; isLiked?: boolean; isBookmarked?: boolean; publishedAt: string | null };
export type Comment = { id: string; body: string; author: User; createdAt: string; replies: Comment[] };
export type Profile = User & { followersCount: number; followingCount: number; postsCount: number; isFollowing: boolean };
export type Notification = { id: string; type: string; message: string; read: boolean; createdAt: string };
export type Dashboard = { posts: number; drafts: number; followers: number; totalLikes: number; recentPosts: Post[] };
export type AdPlacement = { id: string; name: string; provider: string | null; providerPlacementId?: string | null; status: "active" | "paused"; slot: "feed" | "article" | "profile" };

const token = () => localStorage.getItem("dev-publish-token");

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set("content-type", "application/json");
  const value = token();
  if (value) headers.set("authorization", `Bearer ${value}`);
  const response = await fetch(`/api${path}`, { ...init, headers });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${response.status})`);
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

const json = (method: string, body?: unknown): RequestInit => ({ method, body: body === undefined ? undefined : JSON.stringify(body) });

export const api = {
  health: () => request<{ status: string }>("/healthz"),
  me: () => contractGetCurrentUser() as Promise<User>,
  login: (body: { email: string; password: string }) => contractLogin(body),
  signup: (body: { email: string; username: string; displayName: string; password: string }) => contractSignup(body),
  logout: () => contractLogout(),
  posts: (params: Record<string, string | number | undefined> = {}) => {
    const query = new URLSearchParams(Object.entries(params).filter(([, value]) => value !== undefined).map(([key, value]) => [key, String(value)]));
    return contractListPosts(Object.fromEntries(query.entries()) as never) as Promise<{ items: Post[]; page: number; limit: number; total: number }>;
  },
  post: (slug: string) => contractGetPost(slug) as Promise<Post>,
  createPost: (body: unknown) => contractCreatePost(body as never) as Promise<Post>,
  updatePost: (slug: string, body: unknown) => contractUpdatePost(slug, body as never) as Promise<Post>,
  deletePost: (slug: string) => contractDeletePost(slug),
  like: (slug: string, active: boolean) => active ? contractLikePost(slug) : contractUnlikePost(slug),
  bookmark: (slug: string, active: boolean) => active ? contractBookmarkPost(slug) : contractRemoveBookmark(slug),
  comments: (slug: string) => contractListComments(slug) as Promise<Comment[]>,
  comment: (slug: string, body: { body: string; parentId?: string | null }) => contractCreateComment(slug, body) as Promise<Comment>,
  profile: (username: string) => contractGetUserProfile(username) as Promise<Profile>,
  updateProfile: (body: { displayName?: string; bio?: string | null; avatarUrl?: string | null }) => request<User>("/users/me", json("PATCH", body)),
  profilePosts: (username: string) => request<Post[]>(`/users/${encodeURIComponent(username)}/posts`),
  follow: (username: string, active: boolean) => active ? contractFollowUser(username) : contractUnfollowUser(username),
  notifications: () => request<Notification[]>("/notifications"),
  readNotification: (id: string) => request<void>(`/notifications/${id}/read`, json("POST")),
  dashboard: () => request<Dashboard>("/dashboard/summary"),
  dashboardPosts: () => request<Array<Post & { authorId: string; updatedAt: string; createdAt: string }>>("/dashboard/posts"),
  bookmarks: () => request<Post[]>("/bookmarks"),
  report: (body: { postId?: string; commentId?: string; reason: string }) => request("/reports", json("POST", body)),
  admin: () => request<{ users: number; posts: number; publishedPosts: number; pendingReports: number }>("/admin/overview"),
  reports: () => request<Array<{ id: string; postId: string | null; commentId: string | null; reason: string; status: string; createdAt: string }>>("/admin/reports"),
  updateReport: (id: string, status: "open" | "resolved" | "dismissed") => request(`/admin/reports/${id}`, json("PATCH", { status })),
  ads: () => request<AdPlacement[]>("/admin/advertising/placements"),
  createAd: (body: unknown) => request<AdPlacement>("/admin/advertising/placements", json("POST", body)),
  updateAd: (id: string, body: unknown) => request<AdPlacement>(`/admin/advertising/placements/${id}`, json("PATCH", body)),
  monetization: () => request<{ grossCents: number; commissionCents: number; netCents: number; plans: Array<{ id: string; name: string; description: string | null; amountCents: number; status: string }> }>("/monetization/summary"),
  createPlan: (body: unknown) => request("/monetization/plans", json("POST", body)),
};