# Dev Publish

Dev Publish is an original, database-driven developer blogging and publishing platform built around real accounts, persisted posts, and community interactions.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the Express API on its managed port.
- `pnpm --filter @workspace/dev-publish run dev` — run the React web app on its managed port.
- `pnpm run typecheck` — typecheck generated libraries, API, frontend, mockup sandbox, and scripts.
- `pnpm run build` — typecheck and build all packages.
- `pnpm --filter @workspace/api-spec run codegen` — regenerate React Query hooks and Zod schemas from the OpenAPI contract.
- `pnpm --filter @workspace/db run push` — apply the Drizzle schema to the development PostgreSQL database.

Required environment:

- `DATABASE_URL` — PostgreSQL connection string provided by Replit.
- `SESSION_SECRET` or `JWT_SECRET` — JWT signing secret. Never commit or display its value.

## Architecture

This is a pnpm monorepo with separate client, server, contract, and data packages:

- `artifacts/dev-publish` — React + React Router frontend. It uses `@workspace/api-client-react` generated hooks and relative `/api` requests.
- `artifacts/api-server` — Express 5 server mounted at `/api`. It owns request validation, authentication, authorization, error handling, and domain routes.
- `lib/api-spec/openapi.yaml` — single source of truth for REST endpoints and payloads.
- `lib/api-client-react` — generated React Query client.
- `lib/api-zod` — generated Zod request/response validators.
- `lib/db` — Drizzle PostgreSQL connection and schema.

## Data model

The relational schema includes users, PostgreSQL-backed sessions, posts, categories, tags, post-tag links, comments with parent replies, likes, bookmarks, follows, notifications, reports, media asset metadata, creator plans, subscriptions, transactions, earnings, payouts, ad placements, and deduplicated ad events.

## Authentication

Registration validates the API contract, hashes passwords with salted Node.js scrypt, stores the user in PostgreSQL, creates a server-side session, and returns a signed JWT. Protected API middleware verifies the JWT signature, expiration, session record, and user identity. Roles are `member`, `moderator`, and `admin`.

## API contract

The OpenAPI contract covers:

- Auth and public profiles.
- Post CRUD with drafts/publishing and search filters.
- Comments/replies, likes, bookmarks, and follow relationships.
- Notifications, dashboard summaries, and admin overview.
- Separate advertising placements plus auditable impression/click event ingestion.

After any contract edit, always run codegen before importing new generated hooks or validators.

## Advertising constraints

Advertising is a separate provider-ready module. It stores provider metadata and verified event IDs, but it does not fabricate clicks, traffic, impressions, or revenue. Provider integration should be added only after deployment and authorization with a legitimate advertising provider.

## Architecture decisions

- OpenAPI is the compatibility boundary between React and Express.
- PostgreSQL is the system of record; the frontend never owns core product data.
- JWTs are paired with database sessions so logout and server-side revocation are possible.
- Ad events are deduplicated and explicitly separate from financial/revenue reporting.
- Core product screens use the shared API client for contract-covered operations and a single authenticated API helper for the additional dashboard, moderation, and monetization endpoints.

## Gotchas

- Do not hand-edit generated files in `lib/api-client-react` or `lib/api-zod`.
- Use the managed workflows rather than starting root-level dev commands.
- Access services through the shared proxy (`/api` and `/`), not hard-coded localhost URLs in browser code.
- Run `pnpm --filter @workspace/api-spec run codegen` after every OpenAPI change.
- Apply development schema changes with Drizzle; production schema changes are handled by the publish flow.